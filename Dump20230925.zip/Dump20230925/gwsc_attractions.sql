-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: localhost    Database: gwsc
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attractions`
--

DROP TABLE IF EXISTS `attractions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attractions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `location` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attractions`
--

LOCK TABLES `attractions` WRITE;
/*!40000 ALTER TABLE `attractions` DISABLE KEYS */;
INSERT INTO `attractions` VALUES (1,'Shwe Dagon Pagoda','There are shwe da gon pagoda.','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3819.566314910775!2d96.14697547475272!3d16.798238819510775!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1eb5e363aab97%3A0x55f0542aad97d8c7!2z4YCb4YC94YC-4YCx4YCQ4YCt4YCC4YCv4YC24YCF4YCx4YCQ4YCu4YCQ4YCx4YCs4YC6LCDhgJvhgJThgLrhgIDhgK_hgJThgLo!5e0!3m2!1smy!2smm!4v1692630221581!5m2!1smy!2smm','64e37de6b8e84.jpg'),(2,'MaHar Myat Mu Ni','This is MaHar Myat Mu Ni','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3700.549951435605!2d96.07592257487335!3d21.95184645543619!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30cb6d4f5ff5e9d5%3A0x9352ca8131e3edf2!2z4YCZ4YCf4YCs4YCZ4YCv4YCU4YCt4YCb4YCv4YCV4YC64YCb4YC-4YCE4YC64YCQ4YCx4YCs4YC64YCZ4YC84YCQ4YC64YCA4YC84YCu4YC4!5e0!3m2!1smy!2smm!4v1692630693029!5m2!1smy!2smm','64df1f26b46b2.jpg'),(3,'Yangon Water Boom','This is Yangon Water Boom','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3820.067070115224!2d96.1977028747522!3d16.773338420204936!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed00c9e28a09%3A0x5aa9871d473f1bb8!2sYangon%20Water%20Boom!5e0!3m2!1smy!2smm!4v1692630819705!5m2!1smy!2smm','64df1ffde1252.jpg'),(5,'Grinnell Glacier Trailhead','this is a popular place to hike near Many Glacier Campground Campsite','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1125.7182713935617!2d-113.66937201480701!3d48.786024978974744!2m3!1f0!2f38.845445935951616!3f0!3m2!1i1024!2i768!4f35!3m3!1m2!1s0x5368b21013fd9cfd%3A0xf505254ad6191bd2!2sGrinnell%20Glacier%20Trailhead!5e1!3m2!1sen!2smm!4v1695398053344!5m2!1sen!2smm\"','650db9a70335a.jpg'),(6,'Iceberg Ptarmigan Trailhead','It\'s a new place for hiking with very beautiful view.','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1361.0210852825548!2d-113.67869452725105!3d48.788103866240476!2m3!1f0!2f38.815797716789525!3f0!3m2!1i1024!2i768!4f35!3m3!1m2!1s0x5368b20c283fe125%3A0x3ba533a17933d096!2sIceberg%20Ptarmigan%20Trailhead!5e1!3m2!1sen!2smm!4v1695398479535!5m2!1sen!2smm','650dbb040931a.jpg'),(7,'Gorge Trail','dswfsafdsfd','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2945.4972444571604!2d-76.52203589999999!3d42.417149699999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d080e243eac4ad%3A0x4eec9dcc8b5f7297!2sGorge%20Trail!5e0!3m2!1sen!2smm!4v1695400318362!5m2!1sen!2smm','651183f5ca91a.jpg'),(8,'Wells Falls','Its one of the attraction near buttermilk','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15412.44037466487!2d-76.50699478814428!3d42.445120784087536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d081942837b9bb%3A0x2c686160b7b27d0!2sWells%20Falls!5e0!3m2!1sen!2smm!4v1695400444829!5m2!1sen!2smm','6511835880b0e.jpeg'),(9,'Thor\'s Cave','Thor\'s Cave (also known as Thor\'s House Cavern and Thyrsis\'s Cave) is a natural cavern located in the Manifold Valley of the White Peak in Staffordshire, England. It is classified as a karst cave. Located in a steep limestone crag, the cave entrance, a symmetrical arch 7.5 metres wide and 10 metres high, is prominently visible from the valley bottom, around 80 metres (260 feet) below. Reached by an easy stepped path from the Manifold Way, the cave is a popular tourist spot, with views over the Manifold Valley. The second entrance is known as the \"West Window\", below which is a second cave, Thor\'s Fissure Cavern.[1]\r\n\r\nThor\'s Cave was served by a railway station on the Leek and Manifold Valley Light Railway from 1904 to 1934; the disused line now forms the Manifold Way.\r\n\r\n','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2396.034297463451!2d-1.8570874237522417!3d53.09161899375293!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487a3cec312b18f5%3A0xee2287a85252c9f3!2sThor&#39;s%20Cave!5e0!3m2!1sen!2smm!4v1695565856910!5m2!1sen!2smm','65104854cf4f3.jpg'),(10,'Manifold Track','The Manifold Way is a footpath and cycle way in Staffordshire, England. Some 8 miles (13 km) in length, it runs from Hulme End (53.1307°N 1.8480°W) in the north to Waterhouses (53.0480°N 1.8654°W) in the south, mostly through the Manifold Valley and the valley of its only tributary, the River Hamps, following the route of the former Leek and Manifold Valley Light Railway, a 2 ft 6 in (762 mm) gauge line which closed in 1934 after a short life.','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2397.445467131979!2d-1.8644949165694444!3d53.06627063423155!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487a3d03735bd303%3A0x2208af39cedb70e5!2sThe%20Manifold%20Way%2C%20United%20Kingdom!5e0!3m2!1sen!2smm!4v1695566008300!5m2!1sen!2smm','651184a08180a.jpg'),(11,'White Abby','Whitby Abbey was a 7th-century Christian monastery that later became a Benedictine abbey. The abbey church was situated overlooking the North Sea on the East Cliff above Whitby in North Yorkshire, England, a centre of the medieval Northumbrian kingdom. The abbey and its possessions were confiscated by the crown under Henry VIII during the Dissolution of the Monasteries between 1536 and 1545.\r\n\r\nSince that time, the ruins of the abbey have continued to be used by sailors as a landmark at the headland. Since the 20th century, the substantial ruins of the church have been declared a Grade I Listed building and are in the care of English Heritage the site museum is housed in Cholmley House.','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2317.5605651721676!2d-0.6104585236604327!3d54.48833468866864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487f176cde7beea3%3A0xf4d303a702662928!2sWhitby%20Abbey!5e0!3m2!1sen!2smm!4v1695568692440!5m2!1sen!2smm','651053b742d59.jpg'),(12,'Castle Howard','Castle Howard is a stately home in North Yorkshire, England, within the civil parish of Henderskelfe, located 15 miles (24 km) north of York. It is a private residence and has been the home of the Carlisle branch of the Howard family for more than 300 years. Castle Howard is not a fortified structure, but the term \"castle\" is sometimes used in the name of an English country house that was built on the site of a former castle.\r\n\r\nThe house is familiar to television and film audiences as the fictional \"Brideshead\", both in Granada Television\'s 1981 adaptation of Evelyn Waugh\'s Brideshead Revisited and in a two-hour 2008 adaptation for cinema.','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2338.2889538249347!2d-0.9087031236847327!3d54.12180641642041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487ed4f4445a8f9d%3A0xc2c99b82c0de7561!2sCastle%20Howard!5e0!3m2!1sen!2smm!4v1695568864976!5m2!1sen!2smm','65105456ba3f2.jpg'),(13,'Snowdon Ranger Path','Snowdon is the highest mountain in Wales, at an elevation of 1,085 metres (3,560 ft) above sea level, and the highest point in the British Isles outside the Scottish Highlands. It is located in Snowdonia National Park (Parc Cenedlaethol Eryri) in Gwynedd (historic county of Caernarfonshire).\r\n\r\nIt is the busiest mountain in the United Kingdom and the third most visited attraction in Wales; in 2019 it was visited by 590,984 walkers, with an additional 140,000 people taking the train. It is designated as a national nature reserve for its rare flora and fauna.\r\n\r\nThe rocks that form Snowdon were produced by volcanoes in the Ordovician period, and the massif has been extensively sculpted by glaciation, forming the pyramidal peak of Snowdon and the arêtes of Crib Goch and Y Lliwedd. The cliff faces on Snowdon, including Clogwyn Du\'r Arddu, are significant for rock climbing, and the mountain was used by Edmund Hillary in training for the 1953 ascent of Mount Everest.\r\n\r\n','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21359.980754882043!2d-4.158323708757298!3d53.073530636810325!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4865a7bacdb63db7%3A0x7d5c44569044a2d8!2sSnowdon%20Ranger%20Path!5e0!3m2!1sen!2smm!4v1695647743577!5m2!1sen!2smm','6511886daf757.jpg');
/*!40000 ALTER TABLE `attractions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-25 19:57:44
